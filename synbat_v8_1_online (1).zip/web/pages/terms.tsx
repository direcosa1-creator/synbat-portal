import Layout from '../components/Layout'
export default function Terms(){return <Layout><h2>Termini</h2><p>Bozza termini d’uso.</p></Layout>}
