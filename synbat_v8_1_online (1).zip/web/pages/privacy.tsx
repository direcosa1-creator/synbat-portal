import Layout from '../components/Layout'
export default function Privacy(){return <Layout><h2>Privacy</h2><p>Bozza informativa (GDPR).</p></Layout>}
